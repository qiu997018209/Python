from distutils.core import setup

setup(name="package", version="1.0", description="package's module", author="qiujiahao", py_modules=['my_package.a', 'my_package.b', 'my_package2.c', 'my_package2.d'])