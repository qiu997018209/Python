def aFunc():
	print '........aFunc........'